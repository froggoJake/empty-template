<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'froggo_ck');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/** Limit Wp Post Revisions to Save Memory. */
define( 'WP_POST_REVISIONS', 3 );

/** Secure Wp And Remove Default File Editor */
define('DISALLOW_FILE_EDIT',true);

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Q|=h|}V^L`$Jc8qCO,+iz6S6{)-{OGhQ3JNCCiirJSD)caTR)=>;,_moh[wUY.AY');
define('SECURE_AUTH_KEY',  'HIP;1n?FN*0jC|{1LsBo7+xJQJt8pTqxUBa$]%Gnt%BL6]>;bKB{gsoz>y<~FBp@');
define('LOGGED_IN_KEY',    '9Mb:0ES(t,[^E09[rFIY@D|ZMq9}H`KmLmx0$=TGF~FdT/$VH1q5-Sy#BK:jmp%3');
define('NONCE_KEY',        '+Ns+V$|Gs-EC8q<g]*QJO0Kb6zVU~0{Z#amXOLm6(R}Q?nQ?D%to+y-=WnHL0:T7');
define('AUTH_SALT',        'Lc,|~nz||a&1AIMSpDx$Y}/h|SaGHyS  3y2c]UU[n;KdBBTK>-[rU-YG[Lm2+Ef');
define('SECURE_AUTH_SALT', 'p @YLdOH)x~f{+fk17Er?v;:b:<l2h2pL%skQ;?|1qd8=k_g+i]YtEMF $w66i.n');
define('LOGGED_IN_SALT',   'X?9-fGIA.A<9h&8-.E2lbS,G|qEY/F3~$D$.TR~tqd%2AlFDB^#U|Z0mY_.<n.%~');
define('NONCE_SALT',       '}CotU%ZzWG7rYD];}W~=bO[*L4#I>M>+bi~T<h,h}Xn_P|rI6hd%3#+; Vq5(HiV');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
