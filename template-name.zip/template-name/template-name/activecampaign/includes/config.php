<?php

	define("ACTIVECAMPAIGN_URL", "https://tomasco.api-us1.com");
	define("ACTIVECAMPAIGN_API_KEY", "bf9b6f18dc57c40fdf7ea60677de6095ac84722fd81dee19e76dfbc0d936488fe874153a");

?>