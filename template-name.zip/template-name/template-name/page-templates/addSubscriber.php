<?php
/**
 * Template Name: Add Subscriber
 */
require('./wp-load.php');
require_once("../activecampaign/includes/ActiveCampaign.class.php");


if(isset($_POST['email']) && isset($_POST['list-id']))
{
    $ac = new ActiveCampaign(get_field('active_campaign_api_url'), get_field('active_campaign_api_key'));

    $firstName = '';
    if(isset($_POST['first-name'])) $firstName = strip_tags($_POST['first-name']);
    $email = strip_tags($_POST['email']);
    $list_id = strip_tags($_POST['list-id']);

    $contact = array(
        "email" => $email,
        "first_name" => $firstName,
        "p[{$list_id}]" => $list_id,
        "status[{$list_id}]" => 1, // "Active" status
    );

    $contact_sync = $ac->api("contact/sync", $contact);

    if ((int)$contact_sync->success) {
        // successful request
        $contact_id = (int)$contact_sync->subscriber_id;
        echo "<p class='green'>We’ve sent the download file to your specified email inbox.</p>";
    }
    else {
        echo "<p class='red'>try again.</p>";
        exit();
    }
}

