<?php

add_theme_support( 'title-tag' );
add_theme_support( 'woocommerce' );

if(isset($_GET['custom-download'])){
    global $wp_rewrite;
    add_rewrite_endpoint('download-package', EP_ROOT );
    $wp_rewrite->flush_rules();
    require_once (TEMPLATEPATH.'/downloadPackage.php');
    die;
}

add_theme_support( 'post-thumbnails' );
add_theme_support( 'menus' );

/**
 * Register WP menus
 */
register_nav_menus( array(
        'header-menu' => 'Header menu',
        'footer_menu_left' => 'Footer menu left',
        'footer_menu_middle' => 'Footer menu middle',
        'footer_menu_right' => 'Footer menu right'
));

/**
 * Register sidebars
 */
function addSidebars()
{

    $args = array(
        'name'          => __( 'Right sidebar container', 'membership' ),
        'id'            => 'right-sidebar-container',
        'description'   => '',
        'class'         => ''
    );

    register_sidebar( $args );

    $args = array(
        'name'          => __( 'Left sidebar container', 'membership' ),
        'id'            => 'left-sidebar-container',
        'description'   => '',
        'class'         => ''
    );

    register_sidebar( $args );

}
add_action( 'widgets_init', 'addSidebars' );