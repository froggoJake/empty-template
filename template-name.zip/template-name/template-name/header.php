<?php wp_title('|', true, 'right'); ?>
<?php echo get_template_directory_uri(); ?>
<?php echo esc_url( home_url( '/' ) ) ?>
<?php wp_head(); ?>