<?php

//Function to include CSS and JS scripts into header and footer
//Including JS files argument TRUE passes them to be placed at the footer
function include_css_js_scripts() {
    //Include CSS style scripts
    wp_enqueue_style( 'bootstrap', get_template_directory_uri(). '/stylesheets/bootstrap.min.css','','3.3.6','all');
    if ( is_front_page() || is_singular('team') || is_tax('specialities') || is_singular('case-studies') ||
        is_page_template('page-templates/bezelfish.php' ) || is_singular('speciality') || is_singular('brands') ) {
        wp_enqueue_style('slick-css', get_template_directory_uri() . '/stylesheets/slick.css', '', '1.5.9', 'all');
        wp_enqueue_style('slick-theme-css', get_template_directory_uri() . '/stylesheets/slick-theme.css', '', '1.5.9', 'all');
    }
    if ( is_page_template('page-templates/roi-calculator.php' )) {
        wp_enqueue_style( 'jquery-ui', get_template_directory_uri(). '/stylesheets/jquery-ui.min.css','','1.11.4','all');
    }
    wp_enqueue_style( 'main-style', get_template_directory_uri(). '/stylesheets/main.css','','1.0.0','all');
    wp_enqueue_style( 'custom-style', get_template_directory_uri(). '/stylesheets/custom.css','','1.0.0','all');

    //Include JS scripts
    wp_enqueue_script( 'newest-jquery', get_template_directory_uri() . '/js/vendor/jquery-1.11.3.min.js', array(), '1.11.3', true);
    wp_enqueue_script( 'validate-js', get_template_directory_uri() . '/js/vendor/jquery.validate.min.js', array(), '1.14.0', true);
    if ( is_front_page() || is_singular('team') || is_tax('specialities') || is_singular('case-studies') ||
        is_page_template('page-templates/bezelfish.php' ) || is_singular('speciality') || is_singular('brands') ) {
        wp_enqueue_script( 'slick-js', get_template_directory_uri() . '/js/slick.js', array(), '2.0.0', true);
    }
    wp_enqueue_script( 'bootstrap-js', get_template_directory_uri() . '/js/bootstrap.min.js', array(), '3.3.6', true);
    wp_enqueue_script( 'sticky-sidebar-js', get_template_directory_uri() . '/js/theia-sticky-sidebar.js', array(), '1.2.2', true);
    //Embed javascript file that makes the AJAX request
    wp_enqueue_script( 'optin-request-js', get_template_directory_uri() . '/js/optins.js', array(), '1.0.0', true);
    //declare the URL to the file that handles the AJAX request (wp-admin/admin-ajax.php)
    wp_localize_script( 'optin-request-js', 'AjaxHandle', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
    wp_enqueue_script( 'custom-js', get_template_directory_uri() . '/js/custom.js', array(), '1.0.0', true);
    wp_enqueue_script( 'wistia-js', '//fast.wistia.com/assets/external/E-v1.js', array(), '1.0.0', true);

}
add_action( 'wp_enqueue_scripts', 'include_css_js_scripts' );

//Hide the annoying admin bar in the front end
add_filter('show_admin_bar', '__return_false');

//Remove WP version from header (security reason)
//and other unwanted stuff
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'index_rel_link');

//By adding theme support, we declare that this theme does not use a
//hard-coded <title> tag in the document head, and expect WordPress to
//provide it for us.
add_theme_support( 'title-tag' );

//Add theme support for various items
add_theme_support( 'menus' );
add_theme_support( 'post-thumbnails' );

//Set Thumbnail image sizes
add_image_size( 'home-pop-box', 360, 165, true );


/**
 * Register WP menus
 */
register_nav_menus( array(
    'header-menu'    => __( 'Header menu', 'appterra' ),
    'footer_column1' => __( 'Footer Column 1', 'appterra' ),
    'footer_column2' => __( 'Footer Column 2', 'appterra' ),
));

/**
 * Register sidebars
 */
function addSidebars()
{
    register_sidebar( array(
        'name' => 'Main Sidebar',
        'id' => 'main_sidebar'
    ));

}
add_action( 'widgets_init', 'addSidebars' );


/**
 * Location Taxonomy for [Team] Post Type
 */
add_action('init', 'register_team_taxonomy_location');
function register_team_taxonomy_location() {
    // Add new taxonomy, make it hierarchical (like categories)
    $labels = array(
        'name'              => _x( 'Locantion', 'appterra' ),
        'singular_name'     => _x( 'Locantion', 'appterra' ),
        'search_items'      => __( 'Search Locations', 'appterra' ),
        'all_items'         => __( 'All Locations', 'appterra' ),
        'parent_item'       => __( 'Parent Locantion', 'appterra' ),
        'parent_item_colon' => __( 'Parent Locantion:', 'appterra' ),
        'edit_item'         => __( 'Edit Locantion', 'appterra' ),
        'update_item'       => __( 'Update Locantion', 'appterra' ),
        'add_new_item'      => __( 'Add New Locantion', 'appterra' ),
        'new_item_name'     => __( 'New Locantion Name', 'appterra' ),
        'menu_name'         => __( 'Locations' ),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'show_in_menu'      => true,
        'public' => false,  // it's not public, it shouldn't have it's own permalink, and so on
        'publicly_queriable' => true,  // you should be able to query it
        'exclude_from_search' => true,  // you should exclude it from search results
        'show_in_nav_menus' => false,  // you shouldn't be able to add it to menus
        'has_archive' => false,  // it shouldn't have archive page
    );

    register_taxonomy( 'location', array( 'team' ), $args );
}

/**
 * Case studies post type
 */
add_action('init', 'register_case_study_post_type');
function register_case_study_post_type() {
    register_post_type('case-studies', array(
        'menu_position' => 20,
        'menu_icon' => 'dashicons-format-gallery',
        'label' => 'Case Studies',
        'description' => '',
        'show_in_menu' => true,
        'capability_type' => 'post',
        'map_meta_cap' => true,
        'public' => true,
        'show_ui' => true,
        'hierarchical' => true,
        'rewrite' => array('slug' => 'case-studies', 'with_front' => true),
        'query_var' => true,
        'has_archive' => false,
        'supports' => array('title','editor','thumbnail'),
        'labels' => array (
            'name' => __( 'Case Studies', 'appterra' ),
            'singular_name' => __( 'Case Study', 'appterra' ),
            'menu_name' => __( 'Case Studies', 'appterra' ),
            'add_new' => __( 'Add Case Study', 'appterra' ),
            'add_new_item' => __( 'Add New Case Study', 'appterra' ),
            'edit' => __( 'Edit', 'appterra' ),
            'edit_item' => __( 'Edit Case Study', 'appterra' ),
            'new_item' => __( 'New Case Study', 'appterra' ),
            'view' => __( 'View Case Studies', 'appterra' ),
            'view_item' => __( 'View Case Study', 'appterra' ),
            'search_items' => __( 'Search Case Studies', 'appterra' ),
            'not_found' => __( 'No Case Studies Found', 'appterra' ),
            'not_found_in_trash' => __( 'No Case Studies in Trash', 'appterra' ),
            'parent' => __( 'Parent Case Study', 'appterra' ),
        )
    ));
}


/**
 * Products post type
 */
add_action('init', 'register_products_post_type');
function register_products_post_type() {
    register_post_type('products', array(
        'menu_position' => 20,
        'menu_icon' => 'dashicons-cart',
        'label' => 'products',
        'description' => '',
        'show_in_menu' => true,
        'capability_type' => 'post',
        'map_meta_cap' => true,
        'hierarchical' => false,
        'query_var' => true,
        'public' => false,  // it's not public, it shouldn't have it's own permalink, and so on
        'publicly_queriable' => true,  // you should be able to query it
        'show_ui' => true,  // you should be able to edit it in wp-admin
        'exclude_from_search' => true,  // you should exclude it from search results
        'show_in_nav_menus' => false,  // you shouldn't be able to add it to menus
        'has_archive' => false,  // it shouldn't have archive page
        'rewrite' => false,  // it shouldn't have rewrite rules
        'supports' => array('title','editor','thumbnail'),
        'labels' => array (
            'name' => __( 'Products', 'appterra' ),
            'singular_name' => __( 'Product', 'appterra' ),
            'menu_name' => __( 'Products', 'appterra' ),
            'add_new' => __( 'Add Product', 'appterra' ),
            'add_new_item' => __( 'Add New Product', 'appterra' ),
            'edit' => __( 'Edit', 'appterra' ),
            'edit_item' => __( 'Edit Product', 'appterra' ),
            'new_item' => __( 'New Product', 'appterra' ),
            'view' => __( 'View Products', 'appterra' ),
            'view_item' => __( 'View Products', 'appterra' ),
            'search_items' => __( 'Search Products', 'appterra' ),
            'not_found' => __( 'No Products Found', 'appterra' ),
            'not_found_in_trash' => __( 'No Products Found in Trash', 'appterra' ),
            'parent' => __( 'Parent Product', 'appterra' ),
        )
    ));
}

/**
 * Related posts
 * @param $post
 * @return array|\WP_Query
 */
function get_related_posts($post){
    $relatedPosts = array();
    $currentPostType =  get_post_type_object(get_post_type( $post ));
    $currentPostTypeName = $currentPostType->name;
    $postCategories = wp_get_post_categories( $post->ID);

    if(count($postCategories)>0)
    {
        $relatedPosts = new WP_Query(
            array(
                'post_type' => $currentPostTypeName,
                'posts_per_page' => 3,
                'category__in' => $postCategories,
                'post__not_in' => array($post->ID),
                'orderby' => 'rand'
            )
        );
    }
    return $relatedPosts;
}


/**
 * Filter the excerpt "read more" string.
 *
 * @param string $more "Read more" excerpt string.
 * @return string (Maybe) modified "read more" excerpt string.
 */
function excerpt_more( $more ) {
    return '...';
}
add_filter( 'excerpt_more', 'excerpt_more' );

//Edit custom comment form and remove Website URL
add_filter('comment_form_default_fields', 'url_filtered');
function url_filtered($fields)
{
    if(isset($fields['url']))
        unset($fields['url']);
    return $fields;
}
?>